﻿using System;
namespace SnakeGame.Data
{
    public class Serpiente
    {
        private int Longitud { get; set; }
        private int Velocidad { get; set; }
        private int PosicionX { get; set; }
        private int PosicionY { get; set; }
    }
}
