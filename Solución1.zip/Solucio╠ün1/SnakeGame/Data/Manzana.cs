﻿using System;
namespace SnakeGame.Data
{
    public class Manzana
    {
        private int PosicionX { get; set; }
        private int PosicionY { get; set; }
    }
}
